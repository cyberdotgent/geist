#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "geist::geist" for configuration "None"
set_property(TARGET geist::geist APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(geist::geist PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libgeist.so.0.3.0"
  IMPORTED_SONAME_NONE "libgeist.so.0"
  )

list(APPEND _cmake_import_check_targets geist::geist )
list(APPEND _cmake_import_check_files_for_geist::geist "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libgeist.so.0.3.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
